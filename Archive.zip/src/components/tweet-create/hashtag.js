import React from 'react';
import Chip from '@material-ui/core/Chip';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TextField from '@material-ui/core/TextField';

export default function Hashtags() {
  return (
      <div className="tweet-create-hashtag-textfield">
        <Autocomplete
        multiple
        options={hashtags}
        getOptionLabel={option => option.title}
        renderTags={(value, { className, onDelete }) =>
            value.map((option, index) => (
                <Chip
                    key={index}
                    data-tag-index={index}
                    tabIndex={-1}
                    label={option.title}
                    className={className}
                    onDelete={onDelete}
                />
            ))
        }
        renderInput={params => (
            <TextField
                {...params}
                variant="outlined"
                placeholder="Hashtags"
                fullWidth
            />
        )}
        />
      </div>
  );
}

const hashtags = [
    { title: '#happy' },
    { title: '#sad' },
    { title: '#excited' },
    { title: '#bored' },
  ];