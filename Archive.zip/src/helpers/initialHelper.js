export class InitialHelper {
    static getInitial(name) {
        return (name.charAt(0).toUpperCase())
    }
}